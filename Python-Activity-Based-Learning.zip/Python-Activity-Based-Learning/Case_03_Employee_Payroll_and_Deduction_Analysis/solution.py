basic = float(input("Enter basic pay: Rs. "))
overtime = float(input("Enter overtime pay: Rs. "))
incentive = float(input("Enter incentive: Rs. "))

if basic < 0 or overtime < 0 or incentive < 0:
    print("Invalid salary amount")
else:
    allowance = basic * 0.20
    gross = basic + allowance + overtime + incentive
    deduction = gross * 0.10
    net = gross - deduction
    print("\nSALARY STATEMENT")
    print(f"Basic pay: Rs. {basic:.2f}")
    print(f"Allowance: Rs. {allowance:.2f}")
    print(f"Overtime: Rs. {overtime:.2f}")
    print(f"Incentive: Rs. {incentive:.2f}")
    print(f"Gross salary: Rs. {gross:.2f}")
    print(f"Deduction: Rs. {deduction:.2f}")
    print(f"Net salary: Rs. {net:.2f}")
