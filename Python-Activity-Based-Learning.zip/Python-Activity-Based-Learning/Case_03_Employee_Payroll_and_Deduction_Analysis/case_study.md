# Case Study 3: Employee Payroll and Deduction Analysis

## 1. Problem Statement
Calculate gross salary from basic pay, allowance, overtime, and incentive, then apply a simple deduction rate and print a salary statement.

## 2. Objectives
- Calculate gross and net salary.
- Use variables, arithmetic, and formatted output.
- Validate basic pay.

## 3. Assumptions
- Allowance is 20% of basic pay.
- Overtime pay and incentive are entered by the user.
- Deduction is 10% of gross salary.
- All entered amounts must be non-negative.

## 4. Algorithm
1. Read basic pay, overtime pay, and incentive.
2. Validate values.
3. Calculate allowance and gross salary.
4. Calculate deduction as 10% of gross.
5. Calculate net salary.
6. Display the salary statement.

## 5. Flowchart
```text
[Start] -> [Read pay details] -> {All amounts >= 0?} --No--> [Invalid input] -> [End]
                                --Yes--> [Calculate allowance and gross] -> [Calculate deduction and net] -> [Print statement] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  READ basic, overtime, incentive
  IF any value < 0: DISPLAY invalid input
  ELSE
    allowance = basic * 0.20
    gross = basic + allowance + overtime + incentive
    deduction = gross * 0.10
    net = gross - deduction
    DISPLAY salary statement
END
```

## 7. Python Source Code
```python
basic = float(input("Enter basic pay: Rs. "))
overtime = float(input("Enter overtime pay: Rs. "))
incentive = float(input("Enter incentive: Rs. "))

if basic < 0 or overtime < 0 or incentive < 0:
    print("Invalid salary amount")
else:
    allowance = basic * 0.20
    gross = basic + allowance + overtime + incentive
    deduction = gross * 0.10
    net = gross - deduction
    print("\nSALARY STATEMENT")
    print(f"Basic pay: Rs. {basic:.2f}")
    print(f"Allowance: Rs. {allowance:.2f}")
    print(f"Overtime: Rs. {overtime:.2f}")
    print(f"Incentive: Rs. {incentive:.2f}")
    print(f"Gross salary: Rs. {gross:.2f}")
    print(f"Deduction: Rs. {deduction:.2f}")
    print(f"Net salary: Rs. {net:.2f}")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Basic 20000, overtime 1000, incentive 500 | Allowance 4000; gross 25500; deduction 2550; net 22950 |
| Basic -1, overtime 0, incentive 0 | Invalid salary amount |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The program produces a clear salary statement and separates gross salary, deduction, and take-home pay.
