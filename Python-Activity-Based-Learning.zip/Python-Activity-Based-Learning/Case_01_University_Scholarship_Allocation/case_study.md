# Case Study 1: University Scholarship Allocation

## 1. Problem Statement
Determine whether students qualify for a scholarship using aggregate marks, minimum subject marks, attendance, and family income. Rank eligible students by aggregate marks.

## 2. Objectives
- Check all scholarship eligibility conditions.
- Use lists and loops to examine multiple applicants.
- Rank eligible applicants by marks, with higher attendance as the tie-breaker.

## 3. Assumptions
- Aggregate marks and attendance are percentages from 0 to 100.
- Each applicant has three subject marks.
- Eligibility requires aggregate >= 80, every subject >= 70, attendance >= 75, and annual family income <= ₹300000.

## 4. Algorithm
1. Start.
2. Read applicant records.
3. For each applicant, calculate the aggregate from the three subject marks.
4. Check aggregate, subject, attendance, and income conditions.
5. Store eligible applicants in a list.
6. Sort by aggregate descending, then attendance descending.
7. Display the ranked list and stop.

## 5. Flowchart
```text
[Start] -> [Read applicant list] -> [Check each applicant's conditions] -> {Eligible?} --Yes--> [Add to eligible list] -> [Sort by marks and attendance] -> [Display ranking] -> [End]
                                           --No--> [Skip applicant] -> [Next applicant]
```

## 6. Pseudocode
```text
BEGIN
  eligible = empty list
  FOR each applicant
    aggregate = average(subject marks)
    IF aggregate >= 80 AND all subject marks >= 70 AND attendance >= 75 AND income <= 300000
      add applicant to eligible
  SORT eligible by aggregate descending, attendance descending
  DISPLAY eligible
END
```

## 7. Python Source Code
```python
applicants = [
    ("Asha", [88, 91, 84], 92, 250000),
    ("Ravi", [78, 85, 82], 80, 200000),
    ("Meena", [90, 87, 89], 76, 280000),
    ("Kiran", [95, 92, 90], 88, 450000)
]

eligible = []
for name, marks, attendance, income in applicants:
    aggregate = sum(marks) / len(marks)
    if aggregate >= 80 and min(marks) >= 70 and attendance >= 75 and income <= 300000:
        eligible.append((name, aggregate, attendance))

eligible.sort(key=lambda student: (student[1], student[2]), reverse=True)
print("Scholarship Ranking")
if not eligible:
    print("No eligible applicants")
else:
    for rank, student in enumerate(eligible, start=1):
        print(f"{rank}. {student[0]} - Marks: {student[1]:.2f}%, Attendance: {student[2]}%")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Asha: marks 88,91,84; attendance 92; income 250000 | Eligible |
| Ravi: marks 78,85,82; attendance 80; income 200000 | Not eligible: one subject below 70? No; aggregate 81.67, actually eligible |
| Kiran: income 450000 | Not eligible: income exceeds limit |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The program applies multiple conditions to shortlist applicants and sorts eligible students consistently.
