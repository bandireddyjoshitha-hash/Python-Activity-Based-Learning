applicants = [
    ("Asha", [88, 91, 84], 92, 250000),
    ("Ravi", [78, 85, 82], 80, 200000),
    ("Meena", [90, 87, 89], 76, 280000),
    ("Kiran", [95, 92, 90], 88, 450000)
]

eligible = []
for name, marks, attendance, income in applicants:
    aggregate = sum(marks) / len(marks)
    if aggregate >= 80 and min(marks) >= 70 and attendance >= 75 and income <= 300000:
        eligible.append((name, aggregate, attendance))

eligible.sort(key=lambda student: (student[1], student[2]), reverse=True)
print("Scholarship Ranking")
if not eligible:
    print("No eligible applicants")
else:
    for rank, student in enumerate(eligible, start=1):
        print(f"{rank}. {student[0]} - Marks: {student[1]:.2f}%, Attendance: {student[2]}%")
