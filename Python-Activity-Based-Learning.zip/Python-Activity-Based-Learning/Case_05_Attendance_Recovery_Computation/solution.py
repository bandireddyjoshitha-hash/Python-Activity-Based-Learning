attended = int(input("Classes attended: "))
total = int(input("Total classes held: "))
target = 75

if total <= 0 or attended < 0 or attended > total:
    print("Invalid attendance data")
else:
    current = attended / total * 100
    needed = 0
    while (attended + needed) / (total + needed) * 100 < target:
        needed += 1
    print(f"Current attendance: {current:.2f}%")
    print(f"Additional consecutive classes to attend: {needed}")
