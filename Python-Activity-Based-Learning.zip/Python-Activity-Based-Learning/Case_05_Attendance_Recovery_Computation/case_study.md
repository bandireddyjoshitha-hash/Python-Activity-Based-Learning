# Case Study 5: Attendance Recovery Computation

## 1. Problem Statement
Calculate current attendance percentage and determine how many consecutive classes a student must attend to reach a target attendance percentage.

## 2. Objectives
- Calculate attendance percentage.
- Use a loop to find the minimum classes needed.
- Validate class counts.

## 3. Assumptions
- Attended classes cannot exceed total classes.
- Target attendance is 75%.
- Future classes are all attended.

## 4. Algorithm
1. Read attended and total classes.
2. Validate counts.
3. Calculate current percentage.
4. If already at target, display zero additional classes.
5. Otherwise add one attended class at a time until the percentage reaches 75%.
6. Display result.

## 5. Flowchart
```text
[Start] -> [Read attended and total] -> {Valid counts?} --No--> [Error] -> [End]
                               --Yes--> [Calculate percentage] -> {Target reached?} --Yes--> [Needed = 0]
                                                                  --No--> [Loop: add attended classes until target] -> [Display] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  READ attended, total
  IF total <= 0 OR attended < 0 OR attended > total: DISPLAY invalid
  ELSE
    needed = 0
    WHILE (attended + needed) / (total + needed) < 0.75
      needed = needed + 1
    DISPLAY current percentage and needed
END
```

## 7. Python Source Code
```python
attended = int(input("Classes attended: "))
total = int(input("Total classes held: "))
target = 75

if total <= 0 or attended < 0 or attended > total:
    print("Invalid attendance data")
else:
    current = attended / total * 100
    needed = 0
    while (attended + needed) / (total + needed) * 100 < target:
        needed += 1
    print(f"Current attendance: {current:.2f}%")
    print(f"Additional consecutive classes to attend: {needed}")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Attended 60, total 100 | Current 60%; need 60 additional classes to reach 75% |
| Attended 80, total 100 | Current 80%; need 0 additional classes |
| Attended 12, total 0 | Invalid attendance data |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The loop finds the minimum number of future classes required to meet the attendance threshold.
