# Case Study 2: Progressive Electricity Billing

## 1. Problem Statement
Calculate a household's electricity bill using progressive consumption slabs, a fixed charge, and a rebate for low consumption.

## 2. Objectives
- Apply slab-wise calculations.
- Use conditionals and arithmetic operators.
- Print an itemized bill.

## 3. Assumptions
- First 100 units cost ₹2 per unit; next 100 cost ₹3; units above 200 cost ₹5.
- Fixed charge is ₹50.
- Consumption of 100 units or less receives a ₹20 rebate.
- Consumption cannot be negative.

## 4. Algorithm
1. Start and read units.
2. Reject negative units.
3. Calculate energy charge slab by slab.
4. Add ₹50 fixed charge.
5. If units <= 100, subtract ₹20 rebate.
6. Display bill and stop.

## 5. Flowchart
```text
[Start] -> [Input units] -> {Units >= 0?} --No--> [Print invalid input] -> [End]
                         --Yes--> [Calculate progressive slab charge] -> [Add fixed fee] -> {Units <= 100?} -> [Apply rebate if yes] -> [Print bill] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  READ units
  IF units < 0: DISPLAY invalid input
  ELSE
    calculate slab charge
    bill = slab charge + 50
    IF units <= 100: bill = bill - 20
    DISPLAY bill
END
```

## 7. Python Source Code
```python
units = int(input("Enter electricity units: "))
if units < 0:
    print("Invalid units")
else:
    if units <= 100:
        energy_charge = units * 2
    elif units <= 200:
        energy_charge = 100 * 2 + (units - 100) * 3
    else:
        energy_charge = 100 * 2 + 100 * 3 + (units - 200) * 5

    fixed_charge = 50
    rebate = 20 if units <= 100 else 0
    total = energy_charge + fixed_charge - rebate

    print("Energy charge: Rs.", energy_charge)
    print("Fixed charge: Rs.", fixed_charge)
    print("Rebate: Rs.", rebate)
    print("Total bill: Rs.", total)
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Input 80 | Energy 160; fixed 50; rebate 20; total ₹190 |
| Input 150 | Energy 350; fixed 50; rebate 0; total ₹400 |
| Input -4 | Invalid units |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The program calculates electricity charges fairly by applying progressive slabs and a low-use rebate.
