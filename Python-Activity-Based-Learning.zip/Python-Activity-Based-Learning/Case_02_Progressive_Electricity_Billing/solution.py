units = int(input("Enter electricity units: "))
if units < 0:
    print("Invalid units")
else:
    if units <= 100:
        energy_charge = units * 2
    elif units <= 200:
        energy_charge = 100 * 2 + (units - 100) * 3
    else:
        energy_charge = 100 * 2 + 100 * 3 + (units - 200) * 5

    fixed_charge = 50
    rebate = 20 if units <= 100 else 0
    total = energy_charge + fixed_charge - rebate

    print("Energy charge: Rs.", energy_charge)
    print("Fixed charge: Rs.", fixed_charge)
    print("Rebate: Rs.", rebate)
    print("Total bill: Rs.", total)
