products = [
    ("Notebook", 80, 3),
    ("Pen", 20, 5),
    ("Bag", 700, 1)
]
subtotal = 0
print("ITEMIZED INVOICE")
for name, price, quantity in products:
    line_total = price * quantity
    subtotal += line_total
    print(f"{name}: {quantity} x Rs.{price} = Rs.{line_total}")

discount = subtotal * 0.10 if subtotal >= 1000 else 0
taxable_amount = subtotal - discount
tax = taxable_amount * 0.05
total = taxable_amount + tax
print("Subtotal: Rs.", round(subtotal, 2))
print("Discount: Rs.", round(discount, 2))
print("Tax: Rs.", round(tax, 2))
print("Final total: Rs.", round(total, 2))
