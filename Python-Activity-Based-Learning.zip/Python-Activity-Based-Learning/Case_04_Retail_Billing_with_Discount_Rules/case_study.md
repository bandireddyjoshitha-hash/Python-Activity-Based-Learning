# Case Study 4: Retail Billing with Discount Rules

## 1. Problem Statement
Calculate the bill for several products, apply a discount when the subtotal reaches a threshold, and add tax.

## 2. Objectives
- Use lists to store multiple products.
- Calculate subtotal, discount, tax, and final amount.
- Display an itemized invoice.

## 3. Assumptions
- Each product is stored as a tuple of name, price, and quantity.
- A 10% discount applies when subtotal is at least ₹1000.
- Tax is 5% of the discounted subtotal.
- Prices and quantities are non-negative.

## 4. Algorithm
1. Store product tuples in a list.
2. Loop through products and calculate each line total.
3. Add line totals to subtotal.
4. Apply 10% discount if subtotal >= 1000.
5. Calculate 5% tax on discounted subtotal.
6. Display invoice totals.

## 5. Flowchart
```text
[Start] -> [Product list] -> [Loop and add line totals] -> [Subtotal] -> {Subtotal >= 1000?} -> [Discount if yes] -> [Add 5% tax] -> [Print invoice] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  subtotal = 0
  FOR each (name, price, quantity)
    line_total = price * quantity
    subtotal = subtotal + line_total
  IF subtotal >= 1000: discount = subtotal * 0.10 ELSE discount = 0
  taxable = subtotal - discount
  tax = taxable * 0.05
  total = taxable + tax
  DISPLAY totals
END
```

## 7. Python Source Code
```python
products = [
    ("Notebook", 80, 3),
    ("Pen", 20, 5),
    ("Bag", 700, 1)
]
subtotal = 0
print("ITEMIZED INVOICE")
for name, price, quantity in products:
    line_total = price * quantity
    subtotal += line_total
    print(f"{name}: {quantity} x Rs.{price} = Rs.{line_total}")

discount = subtotal * 0.10 if subtotal >= 1000 else 0
taxable_amount = subtotal - discount
tax = taxable_amount * 0.05
total = taxable_amount + tax
print("Subtotal: Rs.", round(subtotal, 2))
print("Discount: Rs.", round(discount, 2))
print("Tax: Rs.", round(tax, 2))
print("Final total: Rs.", round(total, 2))
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Notebook 3x80, Pen 5x20, Bag 1x700 | Subtotal ₹1040; discount ₹104; tax ₹46.80; total ₹982.80 |
| Subtotal below ₹1000 | No discount; tax is 5% of subtotal |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The program automates an itemized bill and applies discount and tax rules in the correct order.
