# Case Study 7: Warehouse Inventory Reconciliation

## 1. Problem Statement
Compare opening stock, received stock, dispatched stock, and recorded closing stock to find discrepancies and replenishment needs.

## 2. Objectives
- Use tuples and lists for product records.
- Calculate expected closing stock.
- Identify discrepancies and shortages.

## 3. Assumptions
- A record contains product name, opening stock, received, dispatched, and recorded closing stock.
- All quantities must be non-negative.
- Target stock is 20 units for each product.

## 4. Algorithm
1. Create a list of product tuples.
2. For each product, calculate expected closing = opening + received - dispatched.
3. Compare expected and recorded closing stock.
4. Calculate replenishment needed to reach target stock of 20.
5. Print results.

## 5. Flowchart
```text
[Start] -> [Read product tuples] -> [For each product calculate expected stock] -> {Expected = recorded?} -> [Report match/discrepancy] -> [Calculate replenishment] -> [Print] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  FOR each product tuple
    expected = opening + received - dispatched
    IF expected == recorded: status = Match ELSE status = Discrepancy
    replenish = maximum(0, 20 - expected)
    DISPLAY product, expected, status, replenish
END
```

## 7. Python Source Code
```python
products = [
    ("Pens", 30, 15, 20, 25),
    ("Books", 40, 10, 25, 30),
    ("Folders", 12, 5, 3, 14)
]
target_stock = 20

print("INVENTORY RECONCILIATION")
for name, opening, received, dispatched, recorded in products:
    expected = opening + received - dispatched
    status = "Match" if expected == recorded else "Discrepancy"
    replenish = max(0, target_stock - expected)
    print(f"{name}: expected={expected}, recorded={recorded}, status={status}, replenish={replenish}")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Pens: 30 opening, 15 received, 20 dispatched, 25 recorded | Expected 25; Match; replenish 0 |
| Books: 40 opening, 10 received, 25 dispatched, 30 recorded | Expected 25; Discrepancy; replenish 0 |
| Expected stock 14 | Replenishment 6 |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The program checks stock records against calculated quantities and highlights products needing correction or replenishment.
