products = [
    ("Pens", 30, 15, 20, 25),
    ("Books", 40, 10, 25, 30),
    ("Folders", 12, 5, 3, 14)
]
target_stock = 20

print("INVENTORY RECONCILIATION")
for name, opening, received, dispatched, recorded in products:
    expected = opening + received - dispatched
    status = "Match" if expected == recorded else "Discrepancy"
    replenish = max(0, target_stock - expected)
    print(f"{name}: expected={expected}, recorded={recorded}, status={status}, replenish={replenish}")
