# Case Study 10: Tuple-Based Product Catalogue Audit

## 1. Problem Statement
Audit product records stored as tuples by checking prices and stock, calculating inventory value, and identifying items that need replenishment.

## 2. Objectives
- Store fixed product records in tuples.
- Use tuple unpacking in a loop.
- Validate records and calculate inventory value.

## 3. Assumptions
- Each tuple contains product ID, product name, price, and stock quantity.
- Price and stock must not be negative.
- Products with fewer than 5 units need replenishment.

## 4. Algorithm
1. Create a list of product tuples.
2. Unpack each tuple in a loop.
3. Flag negative price or stock as invalid.
4. For valid records, calculate price multiplied by stock.
5. Flag stock below 5 for replenishment.
6. Print audit results.

## 5. Flowchart
```text
[Start] -> [Product tuple list] -> [Unpack each tuple] -> {Price and stock valid?} --No--> [Flag invalid]
                                                   --Yes--> [Calculate inventory value] -> {Stock < 5?} -> [Flag replenishment if yes] -> [Print] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  FOR each (id, name, price, stock)
    IF price < 0 OR stock < 0: DISPLAY invalid record
    ELSE
      value = price * stock
      IF stock < 5: status = replenish ELSE status = sufficient
      DISPLAY record and value
END
```

## 7. Python Source Code
```python
products = [
    ("P101", "Notebook", 60.0, 20),
    ("P102", "Marker", 35.0, 3),
    ("P103", "Folder", 25.0, 0),
    ("P104", "Bottle", 120.0, 8)
]

print("PRODUCT CATALOGUE AUDIT")
for product_id, name, price, stock in products:
    if price < 0 or stock < 0:
        print(f"{product_id} {name}: Invalid record")
    else:
        value = price * stock
        status = "Replenishment required" if stock < 5 else "Stock sufficient"
        print(f"{product_id} {name}: value=Rs.{value:.2f}, stock={stock}, {status}")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| P101 price 60, stock 20 | Inventory value ₹1200; stock sufficient |
| P102 price 35, stock 3 | Inventory value ₹105; replenishment required |
| Negative price or stock | Invalid record |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The program demonstrates tuple unpacking and validates catalogue data while identifying low-stock products.
