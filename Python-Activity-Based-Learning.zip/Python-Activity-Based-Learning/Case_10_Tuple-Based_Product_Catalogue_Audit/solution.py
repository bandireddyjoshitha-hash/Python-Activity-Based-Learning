products = [
    ("P101", "Notebook", 60.0, 20),
    ("P102", "Marker", 35.0, 3),
    ("P103", "Folder", 25.0, 0),
    ("P104", "Bottle", 120.0, 8)
]

print("PRODUCT CATALOGUE AUDIT")
for product_id, name, price, stock in products:
    if price < 0 or stock < 0:
        print(f"{product_id} {name}: Invalid record")
    else:
        value = price * stock
        status = "Replenishment required" if stock < 5 else "Stock sufficient"
        print(f"{product_id} {name}: value=Rs.{value:.2f}, stock={stock}, {status}")
