balance = 5000.0
history = []

while True:
    kind = input("Transaction (D=deposit, W=withdraw, X=exit): ").upper()
    if kind == "X":
        break
    if kind not in ("D", "W"):
        print("Invalid transaction type")
        continue
    amount = float(input("Amount: Rs. "))
    if amount <= 0:
        print("Amount must be positive")
    elif kind == "D":
        balance += amount
        history.append(("Deposit", amount, balance))
        print("Deposit successful")
    elif amount <= balance:
        balance -= amount
        history.append(("Withdrawal", amount, balance))
        print("Withdrawal successful")
    else:
        print("Insufficient balance")

print("\nTRANSACTION SUMMARY")
for kind, amount, remaining in history:
    print(f"{kind}: Rs.{amount:.2f}; Balance: Rs.{remaining:.2f}")
print(f"Final balance: Rs.{balance:.2f}")
