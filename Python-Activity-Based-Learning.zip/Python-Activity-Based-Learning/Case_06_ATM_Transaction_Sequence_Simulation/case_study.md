# Case Study 6: ATM Transaction Sequence Simulation

## 1. Problem Statement
Simulate deposits and withdrawals, update the account balance, reject invalid transactions, and show a transaction summary.

## 2. Objectives
- Use loops and conditionals for transaction processing.
- Maintain balance safely.
- Store transaction history in a list.

## 3. Assumptions
- Starting balance is ₹5000.
- Transactions are entered as D for deposit or W for withdrawal, followed by a positive amount.
- A withdrawal cannot exceed the current balance.
- Enter X to finish.

## 4. Algorithm
1. Set balance to ₹5000 and create an empty history list.
2. Repeatedly read transaction type and amount.
3. Stop when type is X.
4. Validate amount and transaction type.
5. For valid deposits, add to balance; for valid withdrawals, check balance first.
6. Record accepted transactions and display final summary.

## 5. Flowchart
```text
[Start] -> [Balance = 5000] -> [Read transaction] -> {Type X?} --Yes--> [Print summary] -> [End]
                                      --No--> [Validate type and amount] -> [Apply if valid] -> [Record] -> [Next transaction]
```

## 6. Pseudocode
```text
BEGIN
  balance = 5000
  history = empty list
  REPEAT
    READ type
    IF type == X: EXIT LOOP
    READ amount
    IF amount <= 0: reject
    ELSE IF type == D: balance = balance + amount; record
    ELSE IF type == W AND amount <= balance: balance = balance - amount; record
    ELSE: reject
  DISPLAY balance and history
END
```

## 7. Python Source Code
```python
balance = 5000.0
history = []

while True:
    kind = input("Transaction (D=deposit, W=withdraw, X=exit): ").upper()
    if kind == "X":
        break
    if kind not in ("D", "W"):
        print("Invalid transaction type")
        continue
    amount = float(input("Amount: Rs. "))
    if amount <= 0:
        print("Amount must be positive")
    elif kind == "D":
        balance += amount
        history.append(("Deposit", amount, balance))
        print("Deposit successful")
    elif amount <= balance:
        balance -= amount
        history.append(("Withdrawal", amount, balance))
        print("Withdrawal successful")
    else:
        print("Insufficient balance")

print("\nTRANSACTION SUMMARY")
for kind, amount, remaining in history:
    print(f"{kind}: Rs.{amount:.2f}; Balance: Rs.{remaining:.2f}")
print(f"Final balance: Rs.{balance:.2f}")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Deposit 1000; withdraw 2000; exit | Final balance ₹4000 |
| Withdraw 9000 from starting balance 5000 | Rejected as insufficient balance; balance remains ₹5000 |
| Amount 0 | Rejected because amount must be positive |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The simulation updates balances only for valid transactions and keeps a record of accepted operations.
