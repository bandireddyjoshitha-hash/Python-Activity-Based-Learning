names = ["Asha", "Ravi", "Meena"]
marks = [
    [88, 91, 84],
    [76, 82, 79],
    [95, 92, 90]
]
top_index = 0
highest_total = -1

print("STUDENT MARKS REPORT")
for i in range(len(marks)):
    total = sum(marks[i])
    average = total / len(marks[i])
    print(f"{names[i]}: total={total}, average={average:.2f}")
    if total > highest_total:
        highest_total = total
        top_index = i

print(f"Top performer: {names[top_index]} with {highest_total} marks")
