# Case Study 9: Student Marks Matrix Analysis

## 1. Problem Statement
Analyze student marks stored in a nested list, calculate each student's total and average, and find the highest-performing student.

## 2. Objectives
- Represent marks using a nested list.
- Calculate row-wise statistics.
- Identify the top performer.

## 3. Assumptions
- Each row contains one student's marks in three subjects.
- Marks are from 0 to 100.
- Student names are stored in a separate list in the same order.

## 4. Algorithm
1. Store student names and marks matrix.
2. For each row, calculate total and average.
3. Print each student's statistics.
4. Track the highest total and print the top performer.

## 5. Flowchart
```text
[Start] -> [Names and marks matrix] -> [Loop through each row] -> [Calculate total and average] -> [Compare total with highest] -> [Display results and top student] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  highest_total = -1
  FOR each student row
    total = sum(row)
    average = total / number of subjects
    DISPLAY student, total, average
    IF total > highest_total: update top student
  DISPLAY top student
END
```

## 7. Python Source Code
```python
names = ["Asha", "Ravi", "Meena"]
marks = [
    [88, 91, 84],
    [76, 82, 79],
    [95, 92, 90]
]
top_index = 0
highest_total = -1

print("STUDENT MARKS REPORT")
for i in range(len(marks)):
    total = sum(marks[i])
    average = total / len(marks[i])
    print(f"{names[i]}: total={total}, average={average:.2f}")
    if total > highest_total:
        highest_total = total
        top_index = i

print(f"Top performer: {names[top_index]} with {highest_total} marks")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Asha 88,91,84 | Total 263; average 87.67 |
| Meena 95,92,90 | Total 277; average 92.33; top performer |
| Three students with valid marks | One summary line per student and a top performer |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
The program uses a nested list to summarize marks and determine the highest-performing student.
