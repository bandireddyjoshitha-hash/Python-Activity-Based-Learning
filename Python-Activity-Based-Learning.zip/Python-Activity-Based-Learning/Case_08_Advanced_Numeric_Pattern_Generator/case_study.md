# Case Study 8: Advanced Numeric Pattern Generator

## 1. Problem Statement
Generate a symmetric hollow diamond pattern for a positive odd width.

## 2. Objectives
- Practice nested loops and conditions.
- Generate aligned text patterns.
- Validate the requested width.

## 3. Assumptions
- The width must be a positive odd integer.
- The widest row contains the requested number of positions.
- The pattern uses asterisks at the outline and spaces inside.

## 4. Algorithm
1. Read width.
2. Reject values less than 1 or even values.
3. Set half = width // 2.
4. For each row from top to bottom, calculate leading spaces and outline positions.
5. Print the upper and lower halves using nested loops.

## 5. Flowchart
```text
[Start] -> [Input odd width] -> {Positive and odd?} --No--> [Error] -> [End]
                                  --Yes--> [Loop over rows] -> [Print spaces and outline stars] -> [End]
```

## 6. Pseudocode
```text
BEGIN
  READ width
  IF width < 1 OR width is even: DISPLAY invalid
  ELSE
    FOR row from 0 to width-1
      distance = min(row, width-1-row)
      leading_spaces = half - distance
      inner_spaces = 2 * distance - 1
      print leading spaces and outline stars
END
```

## 7. Python Source Code
```python
width = int(input("Enter a positive odd width: "))
if width < 1 or width % 2 == 0:
    print("Width must be a positive odd number")
else:
    half = width // 2
    for row in range(width):
        distance = min(row, width - 1 - row)
        leading = half - distance
        print(" " * leading, end="")
        if distance == 0:
            print("*")
        else:
            print("*" + " " * (2 * distance - 1) + "*")
```

## 8. Test Cases
| Test input/scenario | Expected result |
|---|---|
| Input 5 |     *;   * *;  *   *;   * *;    * (alignment depends on leading spaces) |
| Input 4 | Width must be a positive odd number |
| Input 1 | * |

## 9. Output Screenshot
Run `solution.py` in Python. A sample console output is included as `output.png`; for interactive programs, enter the test inputs listed above.

## 10. Conclusion
Nested loops and spacing calculations create a symmetric hollow diamond while validating dimensions.
