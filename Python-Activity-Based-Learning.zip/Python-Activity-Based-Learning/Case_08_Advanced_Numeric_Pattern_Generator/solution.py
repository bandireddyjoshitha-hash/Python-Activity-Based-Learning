width = int(input("Enter a positive odd width: "))
if width < 1 or width % 2 == 0:
    print("Width must be a positive odd number")
else:
    half = width // 2
    for row in range(width):
        distance = min(row, width - 1 - row)
        leading = half - distance
        print(" " * leading, end="")
        if distance == 0:
            print("*")
        else:
            print("*" + " " * (2 * distance - 1) + "*")
