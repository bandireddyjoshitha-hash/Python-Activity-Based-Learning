# Python Activity-Based Learning

This repository contains 10 beginner-level Python case studies prepared from the supplied assignment brief.

## Selected case studies
1. University Scholarship Allocation
2. Progressive Electricity Billing
3. Employee Payroll and Deduction Analysis
4. Retail Billing with Discount Rules
5. Attendance Recovery Computation
6. ATM Transaction Sequence Simulation
7. Warehouse Inventory Reconciliation
8. Advanced Numeric Pattern Generator
9. Student Marks Matrix Analysis
10. Tuple-Based Product Catalogue Audit

Each case-study folder contains:
- `case_study.md`: problem statement, objectives, assumptions, algorithm, text flowchart, pseudocode, source code, test cases, output note, and conclusion.
- `solution.py`: runnable Python program.
- `output.png`: illustrative console-output image where applicable.

## How to run
Install Python 3, open a terminal in a case-study folder, and run:
`python solution.py`

Note: The sample outputs are illustrative. For interactive programs, type the input values from the test cases. Review the programs and personalize them if your instructor expects your own implementation.
